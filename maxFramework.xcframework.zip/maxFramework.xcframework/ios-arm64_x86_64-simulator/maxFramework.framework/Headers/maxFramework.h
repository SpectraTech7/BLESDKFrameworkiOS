//
//  maxFramework.h
//  maxFramework
//
//  Created by Spectra-iOS on 15/01/24.
//

#import <Foundation/Foundation.h>

//! Project version number for maxFramework.
FOUNDATION_EXPORT double maxFrameworkVersionNumber;

//! Project version string for maxFramework.
FOUNDATION_EXPORT const unsigned char maxFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <maxFramework/PublicHeader.h>



//
//  BLESDKFramework.h
//  BLESDKFramework
//
//  Created by Spectra-iOS on 11/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for BLESDKFramework.
FOUNDATION_EXPORT double BLESDKFrameworkVersionNumber;

//! Project version string for BLESDKFramework.
FOUNDATION_EXPORT const unsigned char BLESDKFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BLESDKFramework/PublicHeader.h>



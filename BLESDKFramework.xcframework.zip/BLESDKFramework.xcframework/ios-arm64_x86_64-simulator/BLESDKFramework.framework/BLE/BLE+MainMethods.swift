//
//
//  Created by Manoj on 25/01/22.
//

import Foundation
import CoreBluetooth
import CoreLocation

//MARK: -
//MARK: - Main Methods

extension SpectraBLE {
    
    //TODO: INIT SDK CALL
    @objc
    public func initSdk(apiURL: String, apiKey: String) {
        
        self.isTapAndGoEnabled = true
      
        lScannedDevices.removeAll()
        
        UserDefaults.standard.set(false, forKey: "wasPunched")
        UserDefaults.standard.synchronize()
        
        if SpectraBLE.shared.encryptionKey != "" {
            return
        }
      
        let strUrl = apiURL.appending(APITag.facilityInit.rawValue)
        
        let request = MDLInitApiRequest(key: apiKey)
        
        guard let url = URL(string: strUrl) else {
            bleManagerDelegate?.onInitFailure(error: BLEErrorDesc.invalidURL)
            return
        }
        
        let requestBody = try! JSONEncoder().encode(request)
        
        let huRequest = HURequest(withUrl: url,
                                  forHttpMethod: .post,
                                  requestBody: requestBody)
        
        HttpUtility.shared.reqeuest(huRequest: huRequest,
                                    resultType: MDLInitApiResponse.self) { response in
            
            DispatchQueue.main.async {
                
                switch response {
                    
                case .success(let mdlInitApiResponse):
                    print("Response is: \(mdlInitApiResponse?.key ?? "No key saved")")
                    
                    if let `encryptionKey` = mdlInitApiResponse?.key {
                        
                        SpectraBLE.shared.encryptionKey = encryptionKey
                        
                        KeychainHelper.shared.setValue(encryptionKey, forKey: DeviceConstant.CEncryptionKey)
                        
                        self.bleManagerDelegate?.onInitSuccess(SuccessMsg: BLESuccessMessage.sdkInitializeSuccess)
                    }
                    
                case .failure(let huNetworkError):
                    
                    self.bleManagerDelegate?.onInitFailure(error: BleSdkError(
                        errorCode: 21,
                        errorMessage: "Error in initializing sdk: \(huNetworkError.reason ?? "Something went wrong, Please try again")")
                    )
                }
            }
        }
    }
    
    //TODO: START SCANNING CALL
    @objc
    public func startScan() {
        
        self.tagId = BLETapAndGodDefaultValue.shared.tagId
        self.tapAndGoBoardingFloor = BLETapAndGodDefaultValue.shared.tapAndGoBoardingFloor
        self.tapAndGoSelectedFloor = BLETapAndGodDefaultValue.shared.tapAndGoSelectedFloor
        self.tapAndGoDestinationFloor = BLETapAndGodDefaultValue.shared.tapAndGoDestinationFloor
        self.sensitityLevel = BLETapAndGodDefaultValue.shared.sensitivity
        
        scanQueue.async { [weak self] in
            guard let self = self else { return }
            
            if self.centralManager == nil {
                self.centralManager = CBCentralManager(delegate: self,
                                                       queue: nil,
                                                       options: [
                                                        CBCentralManagerScanOptionAllowDuplicatesKey: false,
                                                        CBCentralManagerOptionShowPowerAlertKey: false
                                                       ])
            }
            
            if self.error != nil {
                bleManagerDelegate?.onScanFailure(error: error!)
                return
            }
            
            centralManager?.scanForPeripherals(withServices: [CBUUID(string: DeviceConstant.CDeviceUDID)], options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
            DispatchQueue.main.async {
                self.bleManagerDelegate?.onScanSuccess(successMsg: BLESuccessMessage.scanningStarted)
            }
        }
       //startDeviceRemoveTimer()
    }
    
    //TODO: START SCANNING CALL WITH TAP & GO PARAMETER
    @objc
    public func startScanWithTapAndGo(tapAndGoEnabled: Bool) {
        isTapAndGoEnabled = tapAndGoEnabled
        self.startScan()
    }
    
    //TODO: STOP SCANNING CALL
    @objc
    public func stopScan() {
        self.centralManager?.stopScan()
        stopDeviceRemoveTimer()
        self.centralManager = nil
        self.scannedDevices.removeAll()
        
        tagId = ""
        tapAndGoSelectedFloor = 0
        tapAndGoBoardingFloor = 0
        tapAndGoDestinationFloor = 0
    }
    
    //TODO: INSERT TAP AND GO DATA
    @objc
    public func insertTapAndGoData(tag: String,
                                   destinationFloor: Int,
                                   boardingFloor: Int,
                                   selectedFloor: Int,
                                   sensitivity: Int) {
        
        //If tag id is not numeric then return from there..
//        if !tag.isNumeric {
//            self.bleManagerDelegate?.onBleManagerFailure(error: BLEErrorDesc.tagMustBeNumeric)
//            return
//        }
        if !BLETapAndGodDefaultValue.shared.tagId.isNumeric {
            self.bleManagerDelegate?.onBleManagerFailure(error: BLEErrorDesc.tagMustBeNumeric)
            return
        }
        
//        tagId = tag
//        tapAndGoSelectedFloor = selectedFloor
//        tapAndGoBoardingFloor = boardingFloor
//        tapAndGoDestinationFloor = destinationFloor
        sensitityLevel = sensitivity
        tagId = BLETapAndGodDefaultValue.shared.tagId
        tapAndGoSelectedFloor = BLETapAndGodDefaultValue.shared.tapAndGoSelectedFloor
        tapAndGoBoardingFloor = BLETapAndGodDefaultValue.shared.tapAndGoBoardingFloor
        tapAndGoDestinationFloor = BLETapAndGodDefaultValue.shared.tapAndGoDestinationFloor
        sensitityLevel = BLETapAndGodDefaultValue.shared.sensitivity
        
//        AppLoader.hideLoader()
        self.bleManagerDelegate?.onBleManagerSuccess(successMsg: BLESuccessMessage.tapAndGoDataSavedSuccess)
    }
    
    //TODO: MAKE PUNCH CALL
    @objc
    public func makePunch(tagId: String,
                          destinationFloor: Int,
                          boardingFloor: Int,
                          selectedFloor: Int,
                          deviceUniqueId: String) {
        
        //Check for tag is numeric or other.. if other then return from here with error messsage
        punchQueue.async {
            
            if !tagId.isNumeric || tagId == "" {
                DispatchQueue.main.async {
                    self.bleManagerDelegate?.onBleManagerFailure(error: BLEErrorDesc.tagMustBeNumeric)
                }
                return
            }
            
            var key = SpectraBLE.shared.encryptionKey
            if key == "" {
                if let _key = KeychainHelper.shared.value(forKey: DeviceConstant.CEncryptionKey) {
                    key = _key
                    SpectraBLE.shared.encryptionKey = _key
                } else {
                    DispatchQueue.main.async {
                        self.bleManagerDelegate?.onBleManagerFailure(error: BLEErrorDesc.initSdkFirst)
                    }
                    return
                }
            }
            
            if self.centralManager == nil {
                self.bleManagerDelegate?.onBleManagerFailure(error: BLEErrorDesc.scanningNotStarted)
                return
            }
            
            if self.scannedDevices.count == 0 {
                DispatchQueue.main.async {
                                   self.bleManagerDelegate?.onBleManagerFailure(error: BLEErrorDesc.noDeviceFound)
                               }
                return
            }
            
            var isIdEntered = false
            if deviceUniqueId.isBlank {
                
                let arrSorted = self.scannedDevices.sorted { device1, device2 in
                    let threshold1 = Double(self.getEntryThreshold(device: device1)) // Convert to Double
                    let threshold2 = Double(self.getEntryThreshold(device: device2)) // Convert to Double
                    
                    let thresholdDiff1 = abs((device1.estimateDistance ?? 0.0) - threshold1)
                    let thresholdDiff2 = abs((device2.estimateDistance ?? 0.0) - threshold2)
                    
                    return thresholdDiff1 < thresholdDiff2
                }
                
                if arrSorted.count == 0 {
                    return
                }
                
               if let _foundDevice = arrSorted.currentDevice(forPeripheralId: self.currentPunchedDeviceId ?? "")
                {
                   self.connectedDevice = _foundDevice
               }
                else{
                    self.connectedDevice = arrSorted[0]
                }
                
            } else {
                
                isIdEntered = true
                
                let index = self.scannedDevices.firstIndex { device in
                    return device.peripheralId == deviceUniqueId
                }
                
                if index != nil {
                    
                    if self.scannedDevices.count > index! {
                        self.connectedDevice = self.scannedDevices[index!]
                    }
                }
            }
            
            guard let `peripheralID` = self.connectedDevice?.peripheralId else {
                
                if isIdEntered {
                    self.bleManagerDelegate?.onBleManagerFailure(error: BLEErrorDesc.noDeviceFoundWithUniqueId)
                } else {
                    self.bleManagerDelegate?.onBleManagerFailure(error: BLEErrorDesc.noDeviceFound)
                }
                
                return
            }
            
            let currentTimestamp = Date().timeIntervalSince1970
            let lastPunchDeviceId = UserDefaults.standard.string(forKey: "LastPunchDeviceId")
            let lastPunchReaderId = UserDefaults.standard.string(forKey: "LastPunchReaderId")
            let lastPunchTimestamp = UserDefaults.standard.object(forKey: "LastPunchTimestamp") as? Double ?? 0.0

               
           // 🟢 Check if punch happened in the last minute
            if lastPunchDeviceId == self.connectedDevice?.peripheralId &&
               lastPunchReaderId == tagId &&
               (currentTimestamp - lastPunchTimestamp) < 5 {
               
               // 🟢 Update last punch timestamp so next punch delay starts from now
               UserDefaults.standard.setValue(currentTimestamp, forKey: "LastPunchTimestamp")
               UserDefaults.standard.synchronize()
               
            //   print("⚠️ Punch skipped: Same device and reader punched within 10 second. Last punch time updated.")
               return
           }
            // 🟢 Store new punch details
            UserDefaults.standard.setValue(self.connectedDevice?.peripheralId, forKey: "LastPunchDeviceId")
            UserDefaults.standard.setValue(tagId, forKey: "LastPunchReaderId")
            UserDefaults.standard.setValue(currentTimestamp, forKey: "LastPunchTimestamp")
            UserDefaults.standard.synchronize()
            
            
            self.connectedDevice?.isOutofRange = false
            self.connectedDevice?.wasPunched = true
            self.connectedDevice?.punchTimeStamp = Date().timeIntervalSince1970
            self.scannedDevices.updateDevice(self.connectedDevice!)
            
            BLEEncryption.setEncryptionKey(key)
            BLEEncryption.setPeriphearalId(peripheralID)
            BLEEncryption.setTagId(tagId)
            BLEEncryption.setDestinationFloor("\(destinationFloor)")
            BLEEncryption.setBoardingFloor("\(boardingFloor)")
            BLEEncryption.setSelectedFloor("\(selectedFloor)")
            BLEEncryption.setDeviceType(self.connectedDevice?.deviceType ?? "")
            
            if let manufData = self.connectedDevice?.manufactureData {
                BLEEncryption.setDeviceData(manufData)
            }
            
            self.command = .punch
            
            guard let `peripheralToConnect` = self.connectedDevice?.peripheral else {
                return
            }
        
            let options: [String: Any] = [
                CBConnectPeripheralOptionNotifyOnConnectionKey: true,
                CBConnectPeripheralOptionNotifyOnDisconnectionKey: true,
                CBConnectPeripheralOptionNotifyOnNotificationKey: true
            ]
            
            self.centralManager?.connect(peripheralToConnect, options: options)
        }
    }
    
    
    //TODO: GET DEVICE LIST CALL
    @objc
    public func getDeviceList() {
        
        if centralManager == nil {
            bleManagerDelegate?.onGetDeviceListFailure(error: BLEErrorDesc.scanningNotStarted)
            return
        }
        
        var arrDevices = [[String: Any]]()
        
        for device in scannedDevices {
            
            arrDevices.append(["device_name": "\(device.deviceName ?? "")", "unique_id": "\(device.peripheralId ?? "")"])
        }
        
        if arrDevices.count > 0 {
            bleManagerDelegate?.onGetDeviceListSuccess(successMsg: BLESuccessMessage.deviceListFetchedSuccess,
                                                       deviceArray: arrDevices)
        } else {
            bleManagerDelegate?.onGetDeviceListFailure(error: BLEErrorDesc.noDeviceFound)
        }
    }
    
    //TODO: GET SDK VERSION
    @objc
    public func getSdkVersion() {
        bleManagerDelegate?.onBleManagerSuccess(successMsg: "1.0")
    }
    
    
    //TODO: REMOVE KEY CHAIN VALUE
    @objc
    public func removeKeychain() {
        if KeychainHelper.shared.value(forKey: DeviceConstant.CEncryptionKey) != nil {
            KeychainHelper.shared.removeValue(forKey: DeviceConstant.CEncryptionKey)
            return
        }
    }
}


extension SpectraBLE {
    
    internal func getEntryThreshold(device: BLEDevice) -> Int {
        
        switch sensitityLevel {
            
            //Low
        case 1:
            
            if device.getDeviceType() == DeviceType.XP_PLUS.rawValue ||  device.getDeviceType() == DeviceType.XP_READER_NEW_MTU.rawValue || device.getDeviceType() == DeviceType.XP_PRO_HID.rawValue || device.getDeviceType() == DeviceType.XP_PRO_SPECTRA.rawValue
            {
                return -42
            }
            else if device.getDeviceType() == DeviceType.BST3S.rawValue || device.getDeviceType() == DeviceType.BSC3S.rawValue || device.getDeviceType() == DeviceType.UST3S.rawValue
            {
                return -42
            }
            else if  device.getDeviceType() == DeviceType.XP_READER_OLD.rawValue
            {
                return -62
            }
            else if  device.getDeviceType() == DeviceType.BIOT_OLD.rawValue
            {
                return -37
            }
            
            //Medium
        case 2:
            if device.getDeviceType() == DeviceType.XP_PLUS.rawValue ||  device.getDeviceType() == DeviceType.XP_READER_NEW_MTU.rawValue || device.getDeviceType() == DeviceType.XP_PRO_HID.rawValue || device.getDeviceType() == DeviceType.XP_PRO_SPECTRA.rawValue
            {
                return -48
            }
            else if device.getDeviceType() == DeviceType.BST3S.rawValue || device.getDeviceType() == DeviceType.BSC3S.rawValue || device.getDeviceType() == DeviceType.UST3S.rawValue
            {
                return -48
            }
            else if  device.getDeviceType() == DeviceType.XP_READER_OLD.rawValue
            {
                return -68
            }
            else if  device.getDeviceType() == DeviceType.BIOT_OLD.rawValue
            {
                return -37
            }
            
            //High
        case 3:
            
            if device.getDeviceType() == DeviceType.XP_PLUS.rawValue || device.getDeviceType() == DeviceType.XP_READER_NEW_MTU.rawValue || device.getDeviceType() == DeviceType.XP_PRO_HID.rawValue || device.getDeviceType() == DeviceType.XP_PRO_SPECTRA.rawValue
            {
                return -55
            }
            else if device.getDeviceType() == DeviceType.BST3S.rawValue || device.getDeviceType() == DeviceType.BSC3S.rawValue || device.getDeviceType() == DeviceType.UST3S.rawValue
            {
                return -55
            }
            else if  device.getDeviceType() == DeviceType.XP_READER_OLD.rawValue
            {
                return -73
            }
            else if  device.getDeviceType() == DeviceType.BIOT_OLD.rawValue
            {
                return -37
            }
            
        default:
            return -55
        }
        
        return -55
    }
    
    func getSmoothedRssi(_ rssiArray: [Int]) -> Int {
        guard !rssiArray.isEmpty else { return -99 }

        let maxChange = 4 // Max RSSI jump allowed
        var filteredRssi = [rssiArray.first!] // Start with the first valid value

        // Step 1: Filter out sudden RSSI jumps (Overshoot/Undershoot)
        for i in 1..<rssiArray.count {
            let prev = filteredRssi.last!
            let curr = rssiArray[i]

            if abs(curr - prev) <= maxChange {
                filteredRssi.append(curr) // Only add if within maxChange
            }
        }

        // Edge case: If too many values were removed, use original data
        if filteredRssi.count < 3 {
            filteredRssi = Array(rssiArray.prefix(5)) // Take first 5 values if filtering removed too much
        }

        // Step 2: Weighted Moving Average
        let weights = [0.1, 0.2, 0.3, 0.4] // Newer values get higher weight
        let weightSum = weights.reduce(0, +)

        let weightedAvg = zip(filteredRssi.suffix(weights.count), weights).reduce(0.0) { acc, pair in
            acc + Double(pair.0) * pair.1
        } / weightSum

        // Step 3: Adaptive Exponential Smoothing
        var smoothedRssi = Double(filteredRssi.first!)
        for rssi in filteredRssi.dropFirst() {
            let alpha = abs(rssi - Int(smoothedRssi)) > maxChange ? 0.5 : 0.2 // Adjust α based on fluctuation
            smoothedRssi = alpha * Double(rssi) + (1 - alpha) * smoothedRssi
        }

        return Int(round(smoothedRssi)) // Final stable RSSI
    }
}


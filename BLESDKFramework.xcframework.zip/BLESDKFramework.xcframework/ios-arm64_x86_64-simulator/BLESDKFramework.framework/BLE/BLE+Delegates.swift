//
//
//  Created by Manoj on 11/01/22.
//

import Foundation
import CoreBluetooth
import AudioToolbox
import CoreLocation

//MARK: - BLE central manager delegate methods
//MARK: -

extension SpectraBLE: CBCentralManagerDelegate, CLLocationManagerDelegate {
    
    func advertiseBeacon() {
        if let beaconData = beaconRegion.peripheralData(withMeasuredPower: nil) as? [String: Any] {
            peripheralManager.startAdvertising(beaconData)
        }
    }
    
    
    public func centralManagerDidUpdateState(_ central: CBCentralManager) {
        
        if self.error != nil {
            bleManagerDelegate?.onScanFailure(error: error!)
            return
        }
        
        if central.state == .poweredOn {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                
                self.locationManager.requestAlwaysAuthorization()
                self.locationManager.delegate = self
                let _uuid = UUID(uuidString: "3a4e2bed-0000-1000-8000-00805f9b34fb")
                self.beaconRegion = CLBeaconRegion.init(uuid: _uuid!, identifier: "com.example.MyBeacon1")
                let _beacon = CLBeaconIdentityConstraint(uuid: _uuid!)
                self.locationManager.startRangingBeacons(satisfying: _beacon)
                self.peripheralManager = CBPeripheralManager(delegate: self, queue: nil)
                
                self.startScan()
            }
        }
    }
    
    func getNearestDevice() -> BLEDevice? {
        return scannedDevices.min(by: { $0.estimateDistance ?? 0  > $1.estimateDistance ?? 0 }) // Strongest signal has the highest RSSI (least negative)
    }
    
    
    public func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        
        let deviceId = peripheral.identifier.uuidString
      
        var midValue: Int = 0
        
        if BLETapAndGodDefaultValue.shared.isAllowedPunch != 1 {
            return
        }
        
        if advertisementData.isBOITDevice() {
            return
        }
        
        if advertisementData.getDeviceType() == -1  {
            return
        }
        
        
        var rssiValue = abs(RSSI.intValue)
        
        if RSSI.intValue > 0 {
            return
        }

        // Process each device on a separate background thread
        DispatchQueue.global(qos: .userInitiated).async {
            
        let deviceName = advertisementData["kCBAdvDataLocalName"] as? String ?? ""
          
        let device = BLEDevice(peripheral: peripheral,
                               advertisementData: advertisementData,
                               rssi: RSSI.intValue,
                               deviceTypeInt: advertisementData.getDeviceType(),
                               timestamp: Date().timeIntervalSince1970,
                               rssiHistory: [RSSI.intValue,
                                             0,
                                             0,
                                             0,
                                             0],
                               decisionArray: self.DecisionArray
                                    )
            
            
            // Check if the device already exists in lScannedDevices
            if let existingDeviceIndex = self.lScannedDevices.firstIndex(where: { $0.peripheralId == device.peripheralId }) {
                
                DispatchQueue.main.async {
                    
                    if self.lScannedDevices.count > 0
                    {
                        var existingDevice = self.lScannedDevices[existingDeviceIndex]
                        
                        // Update RSSI history instead of resetting
                       
                        
                        // Keep only the last 20 samples
                        if existingDevice.rssiHistory.count > 5 {
                            existingDevice.rssiHistory.removeFirst()
                        }
                        existingDevice.rssiHistory.append(RSSI.intValue)
                        self.lScannedDevices[existingDeviceIndex] = existingDevice
                        
                        // Get the median RSSI value from updated history
                        
                       // midValue = self.getMidValueFromRSSIWindow(device: device, rssi:RSSI.intValue) ?? 0
                        
                        midValue = self.getSmoothedRssi(existingDevice.rssiHistory) ?? -99
                        
                       // midValue = self.getMedianRSSI(from: existingDevice.rssiHistory)
                      //  print("📡 Median RSSI: \(midValue) for device: \(existingDevice.deviceName) --deviceid: \(existingDevice.peripheralId)")
                        // Move punching logic inside DispatchQueue.main to ensure midValue is updated
    //                    if(deviceId != "85E6681A-8EA8-4EBF-2BBC-765B97808C79"){
    //                        return
    //                    }
                        
                        //self.scannedDevices.updateDevice(<#T##newDevice: BLEDevice##BLEDevice#>)
                        if let device = self.scannedDevices.first(where: { $0.peripheralId == existingDevice.peripheralId }) {
                            device.advertisementData = advertisementData
                            self.scannedDevices.updateDevice(device)
                        }
                        
                        self.processPunching(for: deviceId, device: existingDevice, midValue: midValue)
                    }
                   
                }
                
            } else {
                // New device, initialize properly
                let newDevice = BLEDevice(
                    peripheral: peripheral,
                    advertisementData: advertisementData,
                    rssi: RSSI.intValue,
                    deviceTypeInt: advertisementData.getDeviceType(),
                    timestamp: Date().timeIntervalSince1970,
                    rssiHistory: [RSSI.intValue,
                                  0,
                                  0,
                                  0,
                                  0],
                    decisionArray: self.DecisionArray
                )
                
                let timestamp = Date()
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "mm:ss:SSS"  // Minutes:Seconds:Milliseconds
                let formattedTime = dateFormatter.string(from: timestamp)

                DispatchQueue.main.async {
    
                    midValue = self.getSmoothedRssi(newDevice.rssiHistory) ?? -99
                    
                   // midValue = self.getMedianRSSI(from: newDevice.rssiHistory)
                  //  print("📡 Median RSSI (New Device): \(midValue) for device: --deviceid: \(newDevice.peripheralId)")
                    // Move punching logic inside DispatchQueue.main to ensure midValue is updated
                    
//                    if(deviceId != "85E6681A-8EA8-4EBF-2BBC-765B97808C79"){
//                        return
//                    }
                    
//                    LogManager.shared.writeLog("[\(formattedTime)] MedianRSSI:- \(device.rssiHistory), Median RSSI:- \(midValue), decisionArray:- \(device.decisionArray), Device Type:- \(device.getDeviceType()), Device ID:- \(device.peripheralId), Device name:- \(device.deviceName), timeAppear:- \(formattedTime)")
//                  
                  
                    if !self.lScannedDevices.contains(where: { $0.peripheralId == newDevice.peripheralId }) {
                        self.lScannedDevices.append(newDevice)
                    }
                    self.processPunching(for: deviceId, device: newDevice, midValue: midValue)
                          
                }
            }
        }
    }

    public func processPunching(for deviceId: String, device: BLEDevice, midValue: Int){
       // if device.decisionArray.count >= 20 {
        let timestamp = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "mm:ss:SSS"  // Minutes:Seconds:Milliseconds
        let formattedTime = dateFormatter.string(from: timestamp)

       
        if deviceId == self.currentPunchedDeviceId {
            
            // Avoid repunching if RSSI fluctuation is small
            if let lastRSSI = self.currentPunchedRSSI, abs(lastRSSI - midValue) <= self.rssiStabilityMargin {
                return
            }
           
           
            // If RSSI drops below exitRSSI, clear current device
            if midValue <= self.getEntryThreshold(device: device) {
               
                // Reset decisionArray to 0 for next cycle
               // device.decisionArray = Array(repeating: 0, count: 20)
                
                self.hasVibrated = false  // Prevent continuous vibration
                device.decisionArray.append(2)
                device.decisionArray.removeFirst()
                
//                LogManager.shared.writeLog("[\(formattedTime)] MedianRSSI:- \(device.rssiHistory), Median RSSI:- \(midValue), decisionArray:- \(device.decisionArray), Device Type:- \(device.getDeviceType()), Device ID:- \(device.peripheralId), Device name:- \(device.deviceName), timeAppear:- \(formattedTime)")
//                
                self.currentPunchedDeviceId = nil
                self.currentPunchedRSSI = nil
                
                if device.decisionArray.allSatisfy({ $0 == 2 }) {
                    if scannedDevices.contains(where: { $0.peripheralId == device.peripheralId }) {
                        
                        if let index = scannedDevices.firstIndex(where: { $0.peripheralId == device.peripheralId }) {
                            scannedDevices.remove(at: index)
                        }
                    }
                    
                }
              
               // print("device goes outside")
                UserDefaults.standard.setValue( Date().timeIntervalSince1970, forKey: "LastPunchTime")
                UserDefaults.standard.set(false, forKey: "wasPunched")
                UserDefaults.standard.synchronize()
            }else if midValue >= self.getEntryThreshold(device: device) {
                if self.currentPunchedDeviceId != deviceId {
                    self.currentPunchedDeviceId = deviceId
                    self.currentPunchedRSSI = midValue
                }
                
                device.decisionArray.append(1)
                device.decisionArray.removeFirst()
//                LogManager.shared.writeLog("[\(formattedTime)] MedianRSSI:- \(device.rssiHistory), Median RSSI:- \(midValue), decisionArray:- \(device.decisionArray), Device Type:- \(device.getDeviceType()), Device ID:- \(device.peripheralId), Device name:- \(device.deviceName), timeAppear:- \(formattedTime)")
//               
                 if device.decisionArray.count >= DecisionArrayLength && device.decisionArray.allSatisfy({ $0 != 0 })
                {
                     // Run makeFinalDecision on a background thread
                       DispatchQueue.global(qos: .userInitiated).async {
                           self.makeFinalDecision(device, midValue: midValue)
                       }
                }
            }
            else
            {
              
                // Maintain only the last 20 values
                device.decisionArray.append(1)
                device.decisionArray.removeFirst()
//                LogManager.shared.writeLog("[\(formattedTime)] MedianRSSI:- \(device.rssiHistory), Median RSSI:- \(midValue), decisionArray:- \(device.decisionArray), Device Type:- \(device.getDeviceType()), Device ID:- \(device.peripheralId), Device name:- \(device.deviceName), timeAppear:- \(formattedTime)")
               
                 if device.decisionArray.count >= DecisionArrayLength && device.decisionArray.allSatisfy({ $0 != 0 })
                {
                     // Run makeFinalDecision on a background thread
                       DispatchQueue.global(qos: .userInitiated).async {
                           self.makeFinalDecision(device, midValue: midValue)
                       }
                 }
            }
            
            return
            
        }
        
        if abs(midValue) <= abs(self.getEntryThreshold(device: device)) {
            if self.currentPunchedDeviceId != deviceId {
               // print("Punch device: \(deviceId) device Name:- \(device.deviceName) with RSSI: \(abs(midValue)))")
                
           
                
            self.currentPunchedDeviceId = deviceId
            self.currentPunchedRSSI = abs(midValue)}
            
          
            device.decisionArray.append(1)
            device.decisionArray.removeFirst()
//            LogManager.shared.writeLog("[\(formattedTime)] MedianRSSI:- \(device.rssiHistory), Median RSSI:- \(midValue), decisionArray:- \(device.decisionArray), Device Type:- \(device.getDeviceType()), Device ID:- \(device.peripheralId), Device name:- \(device.deviceName), timeAppear:- \(formattedTime)")
//           
             if device.decisionArray.count >= DecisionArrayLength && device.decisionArray.allSatisfy({ $0 != 0 })
            {
                 // Run makeFinalDecision on a background thread
                   DispatchQueue.global(qos: .userInitiated).async {
                       self.makeFinalDecision(device, midValue: midValue)
                   }
            }
          
        }else{
           
            // Maintain only the last 20 values
            device.decisionArray.append(2)
            device.decisionArray.removeFirst()
//            LogManager.shared.writeLog("[\(formattedTime)] MedianRSSI:- \(device.rssiHistory), Median RSSI:- \(midValue), decisionArray:- \(device.decisionArray), Device Type:- \(device.getDeviceType()), Device ID:- \(device.peripheralId), Device name:- \(device.deviceName), timeAppear:- \(formattedTime)")
            
            if device.decisionArray.allSatisfy({ $0 == 2 }) {
                
                if scannedDevices.contains(where: { $0.peripheralId == device.peripheralId }) {
                    
                    if let index = scannedDevices.firstIndex(where: { $0.peripheralId == device.peripheralId }) {
                        scannedDevices.remove(at: index)
                    }
                }
            }
            
            
            if device.decisionArray.count >= DecisionArrayLength && device.decisionArray.allSatisfy({ $0 != 0 })
            {
                // Run makeFinalDecision on a background thread
                  DispatchQueue.global(qos: .userInitiated).async {
                      self.makeFinalDecision(device, midValue: midValue)
                  }
            }
        
            return
        }
       
        // **Wait until the array has at least one non-zero value before making a decision**
       // waitForNonZeroDecision(device)
        
    }
    
    private func waitForNonZeroDecision(_ device: BLEDevice, midValue: Int) {
//        DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.01) { // Check every 10ms
//
//        decisionCheckTimer?.invalidate()
//            decisionStartTime = Date().timeIntervalSince1970 // Store the start time
//
//        decisionCheckTimer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) { [weak self] timer in
//            guard let self = self else { return }
            
            if device.decisionArray.allSatisfy({ $0 == 0 }) {
                // Still all zeros, wait and check again
              //  print("⏳ Waiting for non-zero values in decision array for \(device.deviceName)...")
              //  LogManager.shared.writeLog("Median RSSI:- \(midValue),  deviceName:- \(device.deviceName), decisionArray:-\(device.decisionArray), timeAppear:- \(Date().timeIntervalSince1970)")
                self.waitForNonZeroDecision(device, midValue: midValue)
            } else {
                // Proceed with the decision process
                
                // Stop the timer when non-zero values appear
                  // timer.invalidate()
                // Calculate elapsed time
                 //  let elapsedTime = Date().timeIntervalSince1970 - (self.decisionStartTime ?? Date().timeIntervalSince1970)
                //   let elapsedMilliseconds = elapsedTime * 1000 // Convert to milliseconds
                   
               //    print("⏱️ Decision time for \(device.deviceName): \(elapsedMilliseconds) ms")
                
                
               
                
                //self.makeFinalDecision(device)
            }
       // }
       // }
    }
    
    func makeFinalDecision(_ device: BLEDevice,midValue: Int) {
        
        var wPunched :Bool = false
        
        // Convert timestamp to minutes, seconds, and milliseconds
        let timestamp = Date()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "ss:SSS"  // Seconds:Milliseconds only
            let formattedTime = dateFormatter.string(from: timestamp)
        
        // Log decision array progress
    //    LogManager.shared.writeLog("[\(formattedTime)] MedianRSSI:- \(device.rssiHistory), Median RSSI:- \(midValue), decisionArray:- \(device.decisionArray), Device Type:- \(device.getDeviceType()), Device ID:- \(device.peripheralId)")
        
            
            if device.decisionArray.allSatisfy({ $0 == 1 }) {
                
                if !scannedDevices.contains(where: { $0.peripheralId == device.peripheralId }) {
                        scannedDevices.append(device)
                    }
                
                self.lastTapTime = Date().timeIntervalSince1970
                
//                if !self.hasVibrated {
//                   AudioServicesPlayAlertSoundWithCompletion(SystemSoundID(kSystemSoundID_Vibrate)) { }
//                   self.hasVibrated = true  // Prevent continuous vibration
//               }
//                
    
//                let elapsedTime = Date().timeIntervalSince1970 - (lastTapTime ?? Date().timeIntervalSince1970)
//                let elapsedMilliseconds = elapsedTime * 1000 // Convert to milliseconds
//               
//                LogManager.shared.writeLog("\n\n\nOne Punch Time after decision making:-   \(elapsedMilliseconds)")
                
                isConnect = true
                
               // print("📡 Device \(device.deviceName) is CONFIRMED inside range.")
                if let wasPunched = UserDefaults.standard.value(forKey: "wasPunched") as? Bool {
                    wPunched = wasPunched
                    // print("Was Punched: \(wasPunched)")
                }
                
    //            UserDefaults.standard.set(midValue, forKey: "lastRSSI")
    //            UserDefaults.standard.synchronize()
    //
                
                //TODO: Tap & Go Logic
                
                if self.isTapAndGoEnabled {
                    
                    self.tagId = BLETapAndGodDefaultValue.shared.tagId
                    self.tapAndGoBoardingFloor = BLETapAndGodDefaultValue.shared.tapAndGoBoardingFloor
                    self.tapAndGoSelectedFloor = BLETapAndGodDefaultValue.shared.tapAndGoSelectedFloor
                    self.tapAndGoDestinationFloor = BLETapAndGodDefaultValue.shared.tapAndGoDestinationFloor
                    self.sensitityLevel = BLETapAndGodDefaultValue.shared.sensitivity
                    
                    
                    if BLETapAndGodDefaultValue.shared.tagId.isBlank ||
                        (BLETapAndGodDefaultValue.shared.tapAndGoBoardingFloor == 0 &&
                         BLETapAndGodDefaultValue.shared.tapAndGoDestinationFloor == 0 &&
                         BLETapAndGodDefaultValue.shared.tapAndGoSelectedFloor == 0) {
                        
                    } else {
                        
                       // print("Punch device: \(deviceId) waspunch= \(wPunched)")
                        
                        if wPunched == false  {
                            
                            // Reset decisionArray to 0 for next cycle
                            UserDefaults.standard.set(true, forKey: "wasPunched")
                            UserDefaults.standard.synchronize()
                            wPunched = true
                            
                            DispatchQueue.main.async {
                                
                              //  self.scannedDevices.removeAll()
                              //  self.scannedDevices.append(device)
                                
                                self.punchQueue.async {
                                    
                                    self.makePunch(tagId: self.tagId,
                                                   destinationFloor: self.tapAndGoDestinationFloor,
                                                   boardingFloor: self.tapAndGoBoardingFloor,
                                                   selectedFloor: self.tapAndGoSelectedFloor,
                                                   deviceUniqueId: "")
                                    
                                   // self.lastTapTime = Date().timeIntervalSince1970
                                }
                            }
                        }
    //                    else if device.isOutofRange == false && midValue == 0
    //                    {
    //                        DispatchQueue.main.async {
    //
    //                            UserDefaults.standard.set(true, forKey: "wasPunched")
    //                            UserDefaults.standard.synchronize()
    //                            wPunched = true
    //
    //                            device.lastPunchRSSI = midValue
    //
    //                            self.scannedDevices.updateDevice(device)
    //                            self.punchQueue.async {
    //
    //                                self.makePunch(tagId: self.tagId,
    //                                               destinationFloor: self.tapAndGoDestinationFloor,
    //                                               boardingFloor: self.tapAndGoBoardingFloor,
    //                                               selectedFloor: self.tapAndGoSelectedFloor,
    //                                               deviceUniqueId: "")
    //
    //                                self.lastTapTime = Date().timeIntervalSince1970
    //                            }
    //                        }
    //                    }
                    }
                }
            }
            else {
               // device.decisionArray = Array(repeating: 0, count: 20)
               // device.decisionArray.removeAll()
              //  print("🚨 Device \(device.deviceName) is NOT inside range (uncertain).")
            }
    }
    
    
    
    public func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
       
        let connectTime = Date().timeIntervalSince1970
      //  print("✅ Connected to device: \(peripheral.identifier.uuidString) at \(connectTime)")
      
        isConnectionOngoing = false
        peripheral.delegate = self
       
        
        if peripheral.state == .connected {
            //connectedPeripheral = peripheral
            //vibrate phone
            peripheral.readRSSI()
            AudioServicesPlayAlertSoundWithCompletion(SystemSoundID(kSystemSoundID_Vibrate)) { }
        }
        
        if let _connectedDevice = scannedDevices.currentDevice(forPeripheralId: peripheral.identifier.uuidString) {
          //  print(_connectedDevice)
          //  print(_connectedDevice.IsXPReader)
        }
        
//        if let connectedDevice = connectedDevice, connectedDevice.IsXPReader {
        if let connectedDevice = connectedDevice, connectedDevice.IsXPReaderWithIntCheck {
            
            if peripheral.services != nil {
                self.peripheral(peripheral, didDiscoverServices: nil)
               
            } else {
                peripheral.discoverServices([CBUUID(string: DeviceConstant.CServiceUuidXPReader)])
            }
            
            return
        }
        
        let discoverStartTime = Date().timeIntervalSince1970
        
       // print("🔍 Discovering Services at \(discoverStartTime)")
        
        if peripheral.services != nil {
            self.peripheral(peripheral, didDiscoverServices: nil)
        } else {
           
            peripheral.discoverServices([CBUUID(string: DeviceConstant.CServiceUuid)])
        }
    }
    
    public func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        
        if error != nil {
          //  print("\n")
          //  print("didFailToConnect: ", error)
          //  print("\n")
            // let _foundDevice = scannedDevices.currentDevice(forPeripheralId: _periId)!
            
            bleManagerDelegate?.onBleManagerFailure(error: BleSdkError(
                errorCode: 22,
                errorMessage: error?.localizedDescription ?? BLEFailureMessage.failedToConnectPeripheral))
        }
        
        let _periId = peripheral.identifier.uuidString
        if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
            device.wasPunched = false
            scannedDevices.updateDevice(device)
        }
        
        isConnectionOngoing = false
        startScan()
    }
    
    public func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        
        if error != nil {
            
           // print("\n")
          //  print("didDisconnectPeripheral: ", error)
          //  print("\n")
            //            bleManagerDelegate?.onBleManagerFailure(error: BleSdkError(
            //                errorCode: 14,
            //                errorMessage: error?.localizedDescription ?? BLEFailureMessage.failedToDisconnectPeripheral))
            
            //            return
//            let _periId = peripheral.identifier.uuidString
//            if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
//                device.wasPunched = false
//                scannedDevices.updateDevice(device)
//            }
            
            //            central.connect(peripheral)
        }
//        let _periId = peripheral.identifier.uuidString
//        if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
//            device.wasPunched = false
//            scannedDevices.updateDevice(device)
//        }
//        //        self.disconnect()
//        //
//        //        self.startScan()
//        //        bleManagerDelegate?.onBleManagerSuccess(successMsg: BLESuccessMessage.peripheralDisconnected)
//        isConnectionOngoing = false
        
        isConnect = false
    }
    
    public func centralManager(_ central: CBCentralManager, connectionEventDidOccur event: CBConnectionEvent, for peripheral: CBPeripheral) {
        
    }
    
    public func centralManager(_ central: CBCentralManager, didUpdateANCSAuthorizationFor peripheral: CBPeripheral) {
        
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didReadRSSI RSSI: NSNumber, error: (any Error)?) {
        
        if let row = self.scannedDevices.firstIndex(where: { ($0.peripheralId ?? "") == peripheral.identifier.uuidString }) {
            
            let foundDictionary = self.scannedDevices[row]
            foundDictionary.lastPunchRSSI = abs(RSSI.intValue)
            foundDictionary.lastPunchTime = Date().timeIntervalSince1970
            self.scannedDevices[row] = foundDictionary
        }
        
    }
    
    //MARK: - LOCATION MANAGER
    public func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        self.advertiseBeacon()
    }
    
    public func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        self.peripheralManager.stopAdvertising()
    }
    
    public func locationManager(_ manager: CLLocationManager, didRange beacons: [CLBeacon], satisfying beaconConstraint: CLBeaconIdentityConstraint) {
        
        //        print("beacon count : ", beacons.count)
        //        self.advertiseBeacon()
        //        self.startScan()
        for beacon in beacons {
            print("Proximity : ",beacon.proximity)
            print("beacon.major :", beacon.major)
            print("beacon.minor : ", beacon.major)
            print("Accuracy : ", beacon.accuracy)
            print("RSSI : %ld", beacon.rssi)
        }
    }
    
    //MARK: - ESTIMATE DISTANCE
    public func estimateDistance(fromRSSI rssi: Int, txPower: Int) -> Double {
//        let txPower = -59 // Reference RSSI at 1 meter. Adjust based on calibration.
        if rssi == 0 {
            return -1.0 // RSSI not available
        }
        
        let ratio = Double(rssi) / Double(txPower)
        if ratio < 1.0 {
            return pow(ratio, 10)
        } else {
            return (0.89976) * pow(ratio, 7.7095) + 0.111
        }
    }
}


//MARK: - BLE peripheral delegate methods
//MARK: -

extension SpectraBLE: CBPeripheralDelegate {
    
    public func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        
        if error != nil {
            
            print("\n")
            print("didDiscoverServices: ", error)
            print("\n")
            
            let _periId = peripheral.identifier.uuidString
            if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
                device.wasPunched = false
                scannedDevices.updateDevice(device)
            }
            
            return
        }
        
        
        let discoverEndTime = Date().timeIntervalSince1970
       // print("⏳ Service Discovery completed at \(discoverEndTime) - Took \(discoverEndTime - lastTapTime) seconds")
    
        
        if let pServices = peripheral.services {
            
            for service in pServices {
                
                if let connectedDevice = connectedDevice, connectedDevice.IsXPReader {
                    
                    peripheral.discoverCharacteristics([CBUUID(string: DeviceConstant.CCharacteristicUuidXPReader), CBUUID(string: DeviceConstant.CCharacteristicUuidForResponseXPReader)], for: service)
                    
                    
                } else {
                    
                    peripheral.discoverCharacteristics([CBUUID(string: DeviceConstant.CCharacteristicUuidForResponse), CBUUID(string: DeviceConstant.CCharacteristicUuid)], for: service)
                    
                }
            }
        }
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        
        
        if error != nil {
            
            print("\n")
            print("didDiscoverCharacteristicsFor: ", error)
            print("\n")
            
            let _periId = peripheral.identifier.uuidString
            if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
                device.wasPunched = false
                scannedDevices.updateDevice(device)
            }
        
        }
        
        let charDiscoverTime = Date().timeIntervalSince1970
      //  print("⏳ Characteristic Discovery completed at \(charDiscoverTime) - Took \(charDiscoverTime - lastTapTime) seconds")

        
        guard let arrChars = service.characteristics else {
            
            let _periId = peripheral.identifier.uuidString
            if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
                device.wasPunched = false
                scannedDevices.updateDevice(device)
            }
            
            return
        }
    
        for characteristic in arrChars {
            
            if let connectedDevice = connectedDevice, connectedDevice.IsXPReader {
                
                if characteristic.uuid == CBUUID(string: DeviceConstant.CCharacteristicUuidXPReader) {
                    
                    peripheral.setNotifyValue(true, for: characteristic)
                    if isConnect == true{
//                        let elapsedTime = Date().timeIntervalSince1970 - (lastTapTime ?? Date().timeIntervalSince1970)
//                        let elapsedMilliseconds = elapsedTime * 1000 // Convert to milliseconds
//                       
//                        LogManager.shared.writeLog("\n\n\nDeviceName:-\(String(describing: connectedDevice.deviceName)) Time taken between connect to punch:-   \(elapsedMilliseconds)")
//                        
                        sendCommandOnDevice(characteristic: characteristic, peripheral: peripheral)
                    }
                    else
                    {
                        disconnect()
                    }
                    
                } else if characteristic.uuid == CBUUID(string: DeviceConstant.CCharacteristicUuidForResponseXPReader) {
                    
                    peripheral.setNotifyValue(true, for: characteristic)
                    peripheral.readValue(for: characteristic)
                    
                }
                
            } else {
                
                if characteristic.uuid == CBUUID(string: DeviceConstant.CCharacteristicUuid) {
                    
                    peripheral.setNotifyValue(true, for: characteristic)
                    
                  //  print("🚀 Writing Command at \(charDiscoverTime)")
                    
                    if isConnect == true{
//                        let elapsedTime = Date().timeIntervalSince1970 - (lastTapTime ?? Date().timeIntervalSince1970)
//                        let elapsedMilliseconds = elapsedTime * 1000 // Convert to milliseconds
//                       
//                        LogManager.shared.writeLog("\n\n\nDeviceName:-\(String(describing: connectedDevice?.deviceName)) Time taken between connect to punch:-   \(elapsedMilliseconds)")
//                        
                        sendCommandOnDevice(characteristic: characteristic, peripheral: peripheral)
                    }
                    else
                    {
                        disconnect()
                    }
                    
                } else if characteristic.uuid == CBUUID(string: DeviceConstant.CCharacteristicUuidForResponse) {
                    
                    peripheral.setNotifyValue(true, for: characteristic)
                    peripheral.readValue(for: characteristic)
                    
                }
            }
        }
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        
        if error != nil {
            let _periId = peripheral.identifier.uuidString
            if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
                device.wasPunched = false
                scannedDevices.updateDevice(device)
            }
            
            return
        }
    
        let _periId = peripheral.identifier.uuidString
        if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
            device.wasPunched = false
            scannedDevices.updateDevice(device)
        }
        
        isConnectionOngoing = false
        if peripheral.state == .connected {
            self.disconnect()
        }
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didWriteValueFor descriptor: CBDescriptor, error: Error?) {
        
        if error != nil {
            //print("didWriteValueFor descriptor : ", error)
        }
        
        let _periId = peripheral.identifier.uuidString
        if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
            device.wasPunched = false
            scannedDevices.updateDevice(device)
        }
        
        isConnectionOngoing = false
        
        if peripheral.state == .connected {
            disconnect()
        }
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        
        if error != nil {
            
            let _periId = peripheral.identifier.uuidString
            if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
                device.wasPunched = false
                scannedDevices.updateDevice(device)
            }
        }
        let _periId = peripheral.identifier.uuidString
        if let device = scannedDevices.currentDevice(forPeripheralId: _periId) {
            device.wasPunched = false
            scannedDevices.updateDevice(device)
        }
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
    }
}

//MARK: - BLE peripheral manager delegate methods
//MARK: -
extension SpectraBLE: CBPeripheralManagerDelegate {
    
    public func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        if peripheral.state == .poweredOn {
            advertiseBeacon()
        }
    }
    
    public func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest) {
        
    }
    
    public func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
        
    }
}

extension [String : Any] {
    
    func isBOITDevice() -> Bool {
        
        guard let addvertData = self["kCBAdvDataManufacturerData"] as? NSData else {
            return false
        }
        let array: [UInt8] = Array(addvertData)
//        print(array)
        if array.indices.contains(5)
        {
            let fifthElement = Int(array[5])
            if fifthElement == 6 || fifthElement == 2 // 6 & 2 = BIOT DEVICES
            {
                return true
            }
            else
            {
                return false
            }
        } else {
            return false
        }
    }
    
    func getDeviceType() -> Int {
        
        guard let addvertData = self["kCBAdvDataManufacturerData"] as? NSData else {
            return -1
        }
        let array: [UInt8] = Array(addvertData)
//        print(array)
        if array.indices.contains(5)
        {
            let fifthElement = Int(array[5])
            return fifthElement
        }
        else
        {
            return -1
        }
    }
    
}
